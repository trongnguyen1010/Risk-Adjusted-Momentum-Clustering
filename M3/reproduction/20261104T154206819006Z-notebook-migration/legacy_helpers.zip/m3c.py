"""Điều phối tái lập M3-C; mọi PIT/ranking/backtest gọi module M3 chính thức."""
from __future__ import annotations

from bisect import bisect_right
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import html
import importlib.util
import json
import math
import os
from pathlib import Path
import csv
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
from delta_t1.m3 import inputs, ranking, universe
from delta_t1.m3.benchmark import benchmark_nav
from delta_t1.m3.engine import run as portfolio_run
from delta_t1.m3.prices import PriceBook
from delta_t1.m3.strategies import Strategies

PIN = json.loads((ROOT / 'M3/sources.json').read_text(encoding='utf-8'))
spec = importlib.util.spec_from_file_location('m3_official_runner', ROOT / 'scripts/run_m3.py')
official = importlib.util.module_from_spec(spec)
spec.loader.exec_module(official)
NAMES = dict(combined='Combined', market_only='Market-only', financial_only='Financial-only',
             equal_weight='Equal-weight', momentum_only='Momentum-only', vnindex='VNINDEX')
RTOL, ATOL = 1e-9, 1e-10


def sha(path):
    return inputs.sha256(path)


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def csv_rows(path):
    with Path(path).open(encoding='utf-8-sig', newline='') as file:
        return list(csv.DictReader(file))


def grouped(rows, key):
    result = defaultdict(list)
    for row in rows:
        result[row[key]].append(row)
    return dict(result)


def equal(actual, expected, context=''):
    if isinstance(actual, bool):
        assert str(actual) == str(expected), (context, actual, expected)
    elif isinstance(actual, (float, int)):
        assert math.isfinite(float(expected)) and math.isclose(float(actual), float(expected), rel_tol=RTOL, abs_tol=ATOL), (context, actual, expected)
    elif actual is None:
        assert expected in (None, ''), (context, actual, expected)
    else:
        assert str(actual) == str(expected), (context, actual, expected)


def compare_rows(actual, expected, context):
    assert len(actual) == len(expected), (context, len(actual), len(expected))
    for index, (left, right) in enumerate(zip(actual, expected)):
        assert set(left) == set(right), (context, index, set(left) ^ set(right))
        for key, value in left.items():
            equal(value, right[key], (context, index, key))


def table(rows, columns=None):
    """Bảng HTML hiển thị trong notebook, không sinh canonical CSV trung gian."""
    from IPython.display import HTML, display
    columns = list(columns or (list(rows[0]) if rows else []))
    def cell(value):
        if value is None:
            return ''
        if isinstance(value, float):
            return f'{value:.8g}'
        return str(value)
    head = ''.join(f'<th>{html.escape(c)}</th>' for c in columns)
    body = ''.join('<tr>' + ''.join(f'<td>{html.escape(cell(row.get(c)))}</td>' for c in columns) + '</tr>' for row in rows)
    display(HTML('<div style="overflow:auto"><table style="border-collapse:collapse;font-size:13px">'
                 '<thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table></div>'))


def source_identity():
    scope = ['src/delta_t1/m3', 'scripts/run_m3.py', 'configs/experiments/m3_strategy_v1.json']
    assert not subprocess.check_output(['git', 'diff', PIN['source_commit'], '--', *scope], cwd=ROOT), 'M3 source khác commit đã pin'
    assert not subprocess.check_output(['git', 'status', '--porcelain', '--', *scope], cwd=ROOT), 'M3 source/config chưa sạch'
    return dict(source_commit=PIN['source_commit'],
                execution_commit=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
                branch=subprocess.check_output(['git', 'branch', '--show-current'], cwd=ROOT, text=True).strip(),
                worktree_status=subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True).strip(),
                python=sys.version.split()[0], executable=sys.executable,
                module_hashes={str(p.relative_to(ROOT)).replace('\\', '/'): sha(p)
                               for p in [*sorted((ROOT / 'src/delta_t1/m3').glob('*.py')), ROOT / 'scripts/run_m3.py']})


def input_paths(config):
    return dict(terminal_sha256=inputs.BUNDLE, indicators_sha256=inputs.INDICATORS,
                availability_sha256=inputs.AVAILABILITY, c8_benchmark_sha256=inputs.BENCHMARK,
                c8_calendar_sha256=inputs.CALENDAR, c8_prices_sha256=inputs.PRICES_C8,
                b_pit_labels_sha256=ROOT / config['financial_pit']['artifact'] / 'labels.csv')


def fingerprint(path):
    stat = path.stat()
    return dict(size=stat.st_size, mtime_ns=stat.st_mtime_ns)


def validate_runs():
    config = read_json(ROOT / PIN['config'])
    assert config['status'] == 'LOCKED' and sha(ROOT / PIN['config']) == PIN['config_sha256']
    runs = {}
    for segment, pin in PIN['runs'].items():
        seal_path = ROOT / pin['seal']
        assert sha(seal_path) == pin['seal_sha256'], segment
        seal = read_json(seal_path)
        folder = ROOT / seal['run']
        manifest = read_json(folder / 'manifest.json')
        assert seal['status'] == 'PASS' and len(seal['artifacts_sha256']) == 33
        assert {p.name for p in folder.iterdir() if p.is_file()} == set(seal['artifacts_sha256'])
        for name, digest in seal['artifacts_sha256'].items():
            assert sha(folder / name) == digest, (segment, name)
        for key in ['git_commit', 'config_sha256', 'inputs_sha256']:
            assert manifest[key] == seal[key]
        assert manifest['git_commit'] == PIN['source_commit']
        assert manifest['config_sha256'] == PIN['config_sha256']
        assert manifest['financial_source'] == 'B_PIT' and not manifest['targets_only'] and not manifest['git_dirty']
        assert manifest['segment'] == segment and manifest['status'] == 'LOCKED'
        runs[segment] = dict(folder=folder, manifest=manifest, seal=seal,
                             metrics=read_json(folder / 'metrics.json'))
    assert runs['development']['manifest']['inputs_sha256'] == runs['holdout']['manifest']['inputs_sha256']
    return config, runs


def preflight(output):
    """Hash đủ input; cùng lượt đọc C8 lưu trần/sàn cho hai segment để tránh scan lặp."""
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    identity = source_identity()
    config, runs = validate_runs()
    expected = runs['development']['manifest']['inputs_sha256']
    dates = {r['date'] for run in runs.values() for r in csv_rows(run['folder'] / 'nav_combined.csv')}
    hashes = {}; limits = []
    paths = input_paths(config)
    for key, path in paths.items():
        before = fingerprint(path)
        if key == 'c8_prices_sha256':
            digest = hashlib.sha256(); seen = set()
            with path.open('rb') as file:
                for line in file:
                    digest.update(line)
                    marker = b'"trade_date": "'
                    pos = line.index(marker) + len(marker)
                    date = line[pos:pos + 10].decode('ascii')
                    if date in dates:
                        row = json.loads(line)
                        pair = row['ticker'], date
                        assert pair not in seen, pair
                        seen.add(pair)
                        limits.append([*pair, row['raw_close'], row['ceiling_price'], row['floor_price']])
            actual = digest.hexdigest()
        else:
            actual = sha(path)
        assert before == fingerprint(path), ('Input bị thay đổi khi đọc', path)
        assert actual == expected[key], key
        hashes[key] = dict(path=str(path.relative_to(ROOT)).replace('\\', '/'), sha256=actual, **before)
    limits_path = output / 'verified_limits.json'
    write_json(limits_path, limits)
    bpit = ROOT / config['financial_pit']['artifact']
    result = dict(status='PASS', created_at=datetime.now(timezone.utc).isoformat(), identity=identity,
                  sources_sha256=sha(ROOT / 'M3/sources.json'), inputs=hashes,
                  bpit_metadata={name: sha(bpit / name) for name in ['manifest.json', 'models.json', 'audit.json']},
                  limits=dict(path=str(limits_path), sha256=sha(limits_path), dates=sorted(dates), rows=len(limits)))
    write_json(output / 'preflight.json', result)
    return result


class Context:
    def __init__(self):
        self.config, self.runs = validate_runs()
        self.identity = source_identity()
        self.output = Path(os.environ.get('M3C_OUTPUT_DIR', str(ROOT / 'M3/reproduction' / datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')))).resolve()
        self.output.mkdir(parents=True, exist_ok=True)
        proof = self.output / 'preflight.json'
        if not proof.exists():
            preflight(self.output)
        self.proof = read_json(proof)
        assert self.proof['status'] == 'PASS' and self.proof['sources_sha256'] == sha(ROOT / 'M3/sources.json')
        assert self.proof['identity']['module_hashes'] == self.identity['module_hashes']
        for key, path in input_paths(self.config).items():
            record = self.proof['inputs'][key]
            assert fingerprint(path) == {k: record[k] for k in ['size', 'mtime_ns']}, ('Cần chạy lại preflight', path)
            assert record['sha256'] == self.runs['development']['manifest']['inputs_sha256'][key]
        bpit = ROOT / self.config['financial_pit']['artifact']
        for name, digest in self.proof['bpit_metadata'].items():
            assert sha(bpit / name) == digest
        self.market = inputs.market_snapshots()
        self.availability = inputs.availability()
        self.indicators = inputs.indicators()
        self.sectors = inputs.sectors()
        financial, order, _, cutoffs = inputs.bpit(bpit, include_cutoffs=True)
        self.cutoffs = cutoffs
        self.strategies = Strategies(self.config, self.market, financial, self.availability,
                                     self.sectors, self.indicators, fin_order=order, financial_cutoffs=cutoffs)
        self.calendar = inputs.calendar()

    def read(self, segment, kind, strategy=None):
        name = f'{kind}_{strategy}.csv' if strategy else f'{kind}.csv'
        return csv_rows(self.runs[segment]['folder'] / name)

    def decisions(self, segment):
        m = self.runs[segment]['manifest']
        return sorted(d for d in self.market if m['segment_start'] <= d <= m['segment_end_date'])

    def execution(self, decision):
        i = bisect_right(self.calendar, decision)
        return self.calendar[i] if i < len(self.calendar) else ''

    def provenance(self):
        return [dict(input=key, **row) for key, row in self.proof['inputs'].items()]

    def pit_samples(self):
        checks = []; counts = []
        for segment in self.runs:
            dates = self.decisions(segment)
            examples = sorted({dates[0], dates[len(dates) // 2], dates[-1],
                               *[d for d in dates if d.endswith(('04-28', '04-29', '04-30'))]})
            for decision in examples:
                result = self.strategies.target_for('combined', decision)
                generated, _ = self.target_rows(segment, 'combined', decision, result)
                original = [r for r in self.read(segment, 'targets', 'combined') if r['decision_date'] == decision]
                compare_rows(generated, original, ('PIT mẫu', segment, decision))
                count = 0
                for row in result['audit']:
                    if row['in_candidate_universe']:
                        year = int(row['financial_year'])
                        usable = self.availability[row['ticker'], year]['usable_from_date']
                        chosen, reason = universe.financial_state(row['ticker'], decision, self.availability,
                                                                 sorted({y for _, y in self.availability}), self.config['stale_months'])
                        assert year == chosen and reason is None
                        assert usable <= decision and self.cutoffs[year] <= decision
                        if count < 3:
                            checks.append(dict(segment=segment, decision_date=decision, ticker=row['ticker'],
                                               financial_year=year, usable_from_date=usable, cutoff=self.cutoffs[year], result='PASS'))
                        count += 1
                counts.append(dict(segment=segment, decision_date=decision, candidates=result['candidates'],
                                   checked_eligible_rows=count, target='PASS'))
        write_json(self.output / '01_verification.json', dict(status='PASS', samples=checks, checks=counts,
                   provenance=self.provenance(), identity=self.identity))
        return checks, counts

    def target_rows(self, segment, strategy, date, result=None):
        result = result or self.strategies.target_for(strategy, date)
        execution = self.execution(date)
        status = result.get('status', 'OK')
        if not execution or execution > self.runs[segment]['manifest']['segment_end_date']:
            status = 'NOT_EXECUTED_SEGMENT_END'
        target = result.get('target') or {}
        rows = [dict(decision_date=date, execution_date=execution, ticker=t, rank=i + 1,
                     target_weight=target[t], candidates=result['candidates'], status=status)
                for i, t in enumerate(result['picks'])]
        if not rows:
            rows = [dict(decision_date=date, execution_date=execution, ticker='', rank='',
                         target_weight='', candidates=result['candidates'], status=status)]
        return rows, result

    def selection(self):
        summary = []; per_period = []
        for segment in self.runs:
            for strategy in self.config['strategies']:
                targets = []; audit = []
                for date in self.decisions(segment):
                    rows, result = self.target_rows(segment, strategy, date)
                    targets.extend(rows); audit.extend(result['audit'])
                    per_period.append(dict(segment=segment, strategy=strategy, decision_date=date,
                                           candidates=result['candidates'], N_selected=len(result['picks']), status=rows[0]['status']))
                compare_rows(targets, self.read(segment, 'targets', strategy), (segment, strategy, 'targets'))
                compare_rows(audit, self.read(segment, 'universe_audit', strategy), (segment, strategy, 'audit'))
                expected = self.runs[segment]['manifest']['counts'][strategy]
                records = [r for r in per_period if r['segment'] == segment and r['strategy'] == strategy]
                assert len(records) == expected['decisions']
                assert sum(r['status'] == 'UNIVERSE_TOO_SMALL' for r in records) == expected['too_small']
                summary.append(dict(segment=segment, strategy=NAMES[strategy], decisions=len(records),
                                    targets_rows=len(targets), audit_rows=len(audit), result='PASS'))
        write_json(self.output / '02_verification.json', dict(status='PASS', summary=summary, periods=per_period))
        return summary, per_period

    def ranking_example(self, segment, date=None):
        date = date or self.decisions(segment)[0]
        result = self.strategies.target_for('combined', date)
        # Percentile population is the official pool BEFORE all-FC-missing exclusion.
        # Using only the final candidate pool could change displayed Market percentiles.
        candidates, _ = self.strategies._universe(date, market_rule=self.config['market_rule'])
        raw = self.strategies._rows(candidates)
        pct = {}
        for key, higher in {**self.config['market_criteria'], **self.config['financial_criteria']}.items():
            pct[key] = ranking.percentiles({t: value.get(key) if higher or value.get(key) is None else -value[key]
                                           for t, value in raw.items()})
        picks = {t: i + 1 for i, t in enumerate(result['picks'])}
        rows = []
        for ticker, score in result.get('scores', {}).items():
            for group, names in [('s_market', self.config['market_criteria']), ('s_fin', self.config['financial_criteria'])]:
                values = [pct[k][ticker] if pct[k][ticker] is not None else .5 for k in names]
                equal(sum(values) / len(values), score[group], ('display percentile', ticker, group))
            row = dict(ticker=ticker, **raw[ticker])
            row.update({f'pct_{k}': v[ticker] if v[ticker] is not None else 0.5 for k, v in pct.items()})
            row.update(S_market=score['s_market'], S_fin=score['s_fin'], combined_score=score['score'],
                       rank=picks.get(ticker), selected=ticker in picks,
                       target_weight=result.get('target', {}).get(ticker) if result.get('target') else None,
                       flags=';'.join(score['missing']))
            rows.append(row)
        rows.sort(key=lambda r: (r['rank'] is None, r['rank'] or 0, -r['combined_score'], r['ticker']))
        return rows

    def backtest(self):
        snapshot = Path(self.proof['limits']['path'])
        assert sha(snapshot) == self.proof['limits']['sha256']
        limits = {(t, d): (r, c, f) for t, d, r, c, f in read_json(snapshot)}
        summary = []; details = {}; curves = {}
        for segment, info in self.runs.items():
            m = info['manifest']; metrics = info['metrics']
            dates = [r['date'] for r in self.read(segment, 'nav', 'combined')]
            book = PriceBook(dates, self.calendar, limits=limits, segment_start=m['segment_start'], segment_end=m['segment_end_date'])
            assert all(m['segment_start'] <= d <= m['segment_end_date'] for t, d in book.volume)
            assert len(book.flags) == metrics['adj_glitches_repaired']
            curves[segment] = {}
            for strategy in self.config['strategies']:
                schedule = []
                for decision, rows in grouped(self.read(segment, 'targets', strategy), 'decision_date').items():
                    execution = rows[0]['execution_date']
                    if not execution or execution > m['segment_end_date']:
                        assert rows[0]['status'] == 'NOT_EXECUTED_SEGMENT_END'
                        continue
                    if rows[0]['status'] == 'UNIVERSE_TOO_SMALL':
                        target = self.strategies.target_for(strategy, decision)['engine_target']
                    else:
                        target = {r['ticker']: float(r['target_weight']) for r in rows if r['ticker']}
                    schedule.append((decision, execution, target))
                assert len(schedule) == m['counts'][strategy]['executed']
                book.limit_missing = set()
                result = portfolio_run(schedule, book.price, book.tradable, end_date=m['end_date'])
                for row in result['ledger']:
                    row['flag'] = 'LIMIT_DATA_MISSING' if row['status'] in ('BUY_FAILED', 'SELL_FAILED') and (row['ticker'], row['date']) in book.limit_missing else ''
                compare_rows(result['ledger'], self.read(segment, 'trade_ledger', strategy), (segment, strategy, 'ledger'))
                compare_rows(result['holdings'], self.read(segment, 'holdings', strategy), (segment, strategy, 'holdings'))
                compare_rows([dict(date=d, nav=v) for d, v in result['nav']], self.read(segment, 'nav', strategy), (segment, strategy, 'nav'))
                compare_rows([dict(date=d, turnover=v) for d, v in result['turnover']], self.read(segment, 'turnover', strategy), (segment, strategy, 'turnover'))
                recalculated = dict(official.metrics(result['nav'], result['turnover'], result['ledger'], result['holdings'], False),
                                   price_stale=len(result['stale']), limit_data_missing=len(book.limit_missing))
                compare_rows([recalculated], [metrics[strategy]], (segment, strategy, 'metrics'))
                assert not any('sharpe' in key for key in recalculated)
                for date, holdings in grouped(result['holdings'], 'date').items():
                    assert sum(r['ticker'] == 'CASH' for r in holdings) == 1
                    equal(sum(r['weight'] for r in holdings), 1, 'sum weights')
                nav_by_date = dict(result['nav'])
                for date, turnover in result['turnover']:
                    rows = [r for r in result['ledger'] if r['date'] == date]
                    equal(sum(r['executed'] for r in rows) / (2 * nav_by_date[date]), turnover, 'turnover ledger')
                    for row in rows:
                        if row['status'] in ('BUY_FAILED', 'SELL_FAILED'):
                            equal(row['executed'], 0, 'failed trade')
                        if row['status'] == 'SCALED':
                            equal(row['executed'], row['intended'] * row['scale'], 'scaled trade')
                assert result['nav'][0][1] == 1 and result['nav'][-1][0] == m['end_date']
                curves[segment][strategy] = result['nav']
                details[segment, strategy] = result
                summary.append(dict(segment=segment, strategy=NAMES[strategy], NAV_rows=len(result['nav']),
                                    ledger_rows=len(result['ledger']), holdings_rows=len(result['holdings']),
                                    final_NAV=result['nav'][-1][1], result='PASS'))
            benchmark = benchmark_nav(inputs.benchmark(), dates)
            compare_rows([dict(date=d, nav=v) for d, v in benchmark], self.read(segment, 'benchmark_vnindex'), (segment, 'benchmark'))
            compare_rows([official.metrics(benchmark, [], [], [], False)], [metrics['vnindex']], (segment, 'benchmark metrics'))
            curves[segment]['vnindex'] = benchmark
        write_json(self.output / '03_verification.json', dict(status='PASS', summary=summary,
                   benchmark='PASS', q17={s: r['metrics']['adj_glitches_repaired'] for s, r in self.runs.items()},
                   source='official engine, canonical targets; Q6 dùng Strategies.target_for', rtol=RTOL, atol=ATOL))
        return summary, details, curves

    def plot(self, curves):
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import matplotlib.dates as mdates
        from datetime import date
        directory = ROOT / 'M3/reports/figures'
        directory.mkdir(parents=True, exist_ok=True)
        paths = []
        blue, orange, ink = '#005A9C', '#B36822', '#333333'
        controls = ['market_only', 'financial_only', 'equal_weight', 'momentum_only']
        def vectors(nav):
            dates = [date.fromisoformat(d) for d, _ in nav]
            values = [v for _, v in nav]
            peak = values[0]; drawdowns = []
            for value in values:
                peak = max(peak, value)
                drawdowns.append((value / peak - 1) * 100)
            return dates, values, drawdowns
        def style_axis(ax, dates):
            ax.grid(alpha=.18)
            ax.set_xlim(dates[0], dates[-1])
            locator = mdates.AutoDateLocator(minticks=3, maxticks=6)
            ax.xaxis.set_major_locator(locator)
            ax.xaxis.set_major_formatter(mdates.ConciseDateFormatter(locator))
            ax.tick_params(labelsize=9)
        note = 'Giá điều chỉnh / VNINDEX chỉ số giá; chi phí = 0. Drawdown đo theo kỳ.'
        for segment, series in curves.items():
            data = {name: vectors(nav) for name, nav in series.items()}
            assert all(value[0] == data['combined'][0] for value in data.values())
            fig, axes = plt.subplots(2, 1, figsize=(10, 7), sharex=True, constrained_layout=True)
            for name, color, linestyle in [('combined', blue, '-'), ('vnindex', ink, '--')]:
                dates, values, drawdowns = data[name]
                axes[0].plot(dates, values, label=NAMES[name], color=color, linewidth=2.2, linestyle=linestyle)
                axes[1].plot(dates, drawdowns, color=color, linewidth=2.2, linestyle=linestyle)
            axes[0].set(title=f'{segment.title()} — Combined và VNINDEX', ylabel='NAV (vốn đầu = 1)')
            axes[1].set(title='Mức giảm từ đỉnh NAV đã đạt', ylabel='Drawdown (%)', xlabel='Ngày định giá')
            axes[0].legend(ncol=2, fontsize=10)
            for ax in axes:
                style_axis(ax, data['combined'][0])
            fig.text(.5, -.01, note, ha='center', fontsize=9)
            file = directory / f'{segment}_nav_drawdown.png'
            fig.savefig(file, dpi=150, bbox_inches='tight'); plt.close(fig)
            paths.append(file)

            fig, axes = plt.subplots(4, 2, figsize=(12, 11), sharex=True, sharey='col', constrained_layout=True)
            fig.suptitle(f'{segment.title()} — Combined với từng strategy đối chứng', fontsize=14)
            for row, control in enumerate(controls):
                for name, color, linestyle in [('combined', blue, '-'), (control, orange, '--')]:
                    dates, values, drawdowns = data[name]
                    axes[row, 0].plot(dates, values, color=color, linewidth=1.8, linestyle=linestyle, label=NAMES[name])
                    axes[row, 1].plot(dates, drawdowns, color=color, linewidth=1.8, linestyle=linestyle)
                axes[row, 0].set(title=f'{NAMES[control]} — NAV', ylabel='NAV')
                axes[row, 1].set(title=f'{NAMES[control]} — Drawdown', ylabel='Drawdown (%)')
                axes[row, 0].legend(loc='upper left', ncol=2, fontsize=8, framealpha=.9)
                for ax in axes[row]:
                    style_axis(ax, data['combined'][0])
            for ax in axes[-1]:
                ax.set_xlabel('Ngày định giá')
            fig.text(.5, -.01, 'Các ô cùng cột dùng chung thang đo. ' + note, ha='center', fontsize=9)
            file = directory / f'{segment}_controls_nav_drawdown.png'
            fig.savefig(file, dpi=150, bbox_inches='tight'); plt.close(fig)
            paths.append(file)
        return paths

    def metrics_table(self, segment):
        metrics = self.runs[segment]['metrics']
        return [dict(strategy=NAMES[name], **metrics[name],
                     too_small=self.runs[segment]['manifest']['counts'][name]['too_small'] if name != 'vnindex' else None)
                for name in [*self.config['strategies'], 'vnindex']]

    def write_report(self):
        """Báo cáo từ metrics nguồn; không nhập tay các kết quả số."""
        from m3c_report import report_text
        path = ROOT / 'M3/reports/BAO_CAO_KY_THUAT_M3.md'
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(report_text(self), encoding='utf-8')
        return path

    def finish(self):
        for key, path in input_paths(self.config).items():
            record = self.proof['inputs'][key]
            assert fingerprint(path) == {k: record[k] for k in ['size', 'mtime_ns']}, ('Input thay đổi trong phiên', path)
        bpit = ROOT / self.config['financial_pit']['artifact']
        for name, digest in self.proof['bpit_metadata'].items():
            assert sha(bpit / name) == digest
        for segment in self.runs:
            seal = self.runs[segment]['seal']
            for name, digest in seal['artifacts_sha256'].items():
                assert sha(self.runs[segment]['folder'] / name) == digest
        source_identity()
        return 'PASS — nguồn canonical giữ nguyên; không có Final performance.'
