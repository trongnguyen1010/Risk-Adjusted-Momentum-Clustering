"""Chạy notebook M3-C bằng kernel sạch; ghi evidence mới, không sửa canonical runs."""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / '.tmp/m3c-notebook-runtime'
if RUNTIME.is_dir():
    sys.path.insert(0, str(RUNTIME))
sys.path.insert(0, str(ROOT / 'M3'))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--notebook', choices=['01', '02', '03', '04', 'all'], default='all')
    args = parser.parse_args()
    if args.notebook == '04':
        parser.error('NOT_READY: chưa có dữ liệu/window/run Final verified + sealed; Notebook 04 không được chạy.')
    import nbformat
    from nbclient import NotebookClient
    from jupyter_client import KernelManager
    from jupyter_client.kernelspec import KernelSpecManager
    from m3c import preflight, sha, validate_runs, write_json

    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    output = ROOT / 'M3/reproduction' / run_id
    proof = preflight(output)
    print('PREFLIGHT_PASS ' + str(output), flush=True)
    cache = ROOT / '.tmp/m3c-jupyter'
    cache.mkdir(parents=True, exist_ok=True)
    for name, subdir in [('IPYTHONDIR', 'ipython'), ('JUPYTER_RUNTIME_DIR', 'runtime'), ('MPLCONFIGDIR', 'matplotlib')]:
        directory = cache / subdir
        directory.mkdir(parents=True, exist_ok=True)
        os.environ[name] = str(directory)
    os.environ['MPLBACKEND'] = 'Agg'
    os.environ['M3C_OUTPUT_DIR'] = str(output)
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    kernel_dir = cache / 'kernels/m3c-frozen'
    kernel_dir.mkdir(parents=True, exist_ok=True)
    bootstrap = f"import sys; sys.path.insert(0, {str(RUNTIME)!r}); from ipykernel.kernelapp import IPKernelApp; IPKernelApp.launch_instance()"
    write_json(kernel_dir / 'kernel.json', dict(argv=[sys.executable, '-I', '-B', '-X', 'utf8', '-c', bootstrap, '-f', '{connection_file}'],
                                               display_name='M3-C Python 3.12 (isolated)', language='python'))
    manager = KernelSpecManager(kernel_dirs=[str(kernel_dir.parent)])
    names = sorted((ROOT / 'M3/notebooks').glob('0[123]_*.ipynb'))
    if args.notebook != 'all':
        names = [p for p in names if p.name.startswith(args.notebook)]
    assert len(names) == (3 if args.notebook == 'all' else 1)
    executed = []
    try:
        for file in names:
            notebook = nbformat.read(file, as_version=4)
            # Validation uses a new kernel for every notebook, with no stale outputs/state.
            for cell in notebook.cells:
                if cell.cell_type == 'code':
                    cell.outputs = []
                    cell.execution_count = None
            nbformat.validate(notebook)
            km = KernelManager(kernel_name='m3c-frozen', kernel_spec_manager=manager,
                               connection_file=str(cache / 'runtime' / f'{run_id}-{file.stem}.json'))
            client = NotebookClient(notebook, km=km, timeout=600, startup_timeout=60, allow_errors=False,
                                    resources={'metadata': {'path': str(ROOT)}})
            print('EXECUTING ' + file.name, flush=True)
            try:
                with (output / f'{file.stem}.kernel.log').open('w', encoding='utf-8') as log:
                    client.execute(stdout=log, stderr=subprocess.STDOUT)
            finally:
                if km.has_kernel:
                    km.shutdown_kernel(now=True)
            assert all(not any(o.output_type == 'error' for o in cell.get('outputs', [])) for cell in notebook.cells)
            notebook.metadata['m3c']['last_evidence'] = str(output.relative_to(ROOT)).replace('\\', '/')
            nbformat.validate(notebook)
            nbformat.write(notebook, file)
            nbformat.write(notebook, output / file.name)
            executed.append(dict(file=str(file.relative_to(ROOT)).replace('\\', '/'), sha256=sha(file),
                                 code_cells=sum(c.cell_type == 'code' for c in notebook.cells), status='PASS'))
            print('NOTEBOOK_PASS ' + file.name, flush=True)
        validate_runs()
        versions = {d.metadata['Name']: d.version for d in importlib.metadata.distributions(path=[str(RUNTIME)])}
        result = dict(historical_status='PASS' if len(executed) == 3 else 'PARTIAL', overall_status='PARTIAL',
                      final_status='NOT_READY', reason='Chưa đủ dữ liệu 2026 và chưa có Final sealed run',
                      notebooks=executed, preflight_sha256=sha(output / 'preflight.json'),
                      source_identity=proof['identity'], package_versions=versions,
                      code_sha256={p.name: sha(p) for p in sorted((ROOT / 'M3').glob('*.py'))},
                      supporting_files_sha256={str(p.relative_to(ROOT)).replace('\\', '/'): sha(p) for p in
                                               [ROOT / 'M3/sources.json', ROOT / 'M3/requirements-notebooks.lock.txt',
                                                ROOT / 'M3/HUONG_DAN_THUC_HIEN_M3.md',
                                                ROOT / 'M3/notebooks/04_Bao_Cao_Danh_Gia_Cuoi.ipynb']},
                      generated_files={str(p.relative_to(ROOT)).replace('\\', '/'): sha(p)
                                       for p in sorted((ROOT / 'M3/reports').rglob('*')) if p.is_file()})
        write_json(output / 'verification.json', result)
        write_json(ROOT / 'M3/reproduction/latest.json', dict(path=str(output.relative_to(ROOT)).replace('\\', '/'),
                                                            verification_sha256=sha(output / 'verification.json')))
        print(json.dumps(dict(historical=result['historical_status'], final='NOT_READY', evidence=str(output)), ensure_ascii=False), flush=True)
    except Exception as error:
        write_json(output / 'failure.json', dict(status='FAIL', completed=executed, error=repr(error)))
        raise


if __name__ == '__main__':
    main()
