"""Kiểm tra các cổng đối chiếu M3-C bằng các trường hợp sai có thể đổi kết luận."""
import copy
from pathlib import Path
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import m3c


class ComparisonGates(unittest.TestCase):
    def test_float_tolerance_accepts_roundoff_but_rejects_material_nav_error(self):
        m3c.equal(1.23456789, '1.2345678900000002')
        with self.assertRaises(AssertionError):
            m3c.equal(1.23456789, '1.2346')

    def test_nonfinite_values_cannot_pass(self):
        for value in ['nan', 'inf', '-inf']:
            with self.assertRaises(AssertionError):
                m3c.equal(1., value)

    def test_missing_is_distinct_from_zero(self):
        m3c.equal(None, '')
        with self.assertRaises(AssertionError):
            m3c.equal(None, 0)

    def test_shifted_rows_missing_columns_and_status_changes_fail(self):
        actual = [dict(ticker='AAA', weight=.5, status='EXECUTED'), dict(ticker='BBB', weight=.5, status='SCALED')]
        for bad in [list(reversed(actual)), [dict(ticker='AAA', weight=.5), actual[1]],
                    [dict(actual[0], status='BUY_FAILED'), actual[1]]]:
            with self.assertRaises(AssertionError):
                m3c.compare_rows(actual, bad, 'negative control')

    def test_bad_pinned_seal_is_rejected(self):
        pins = copy.deepcopy(m3c.PIN)
        pins['runs']['development']['seal_sha256'] = '0' * 64
        with patch.object(m3c, 'PIN', pins), self.assertRaises(AssertionError):
            m3c.validate_runs()

    def test_bad_config_pin_is_rejected(self):
        pins = copy.deepcopy(m3c.PIN)
        pins['config_sha256'] = '0' * 64
        with patch.object(m3c, 'PIN', pins), self.assertRaises(AssertionError):
            m3c.validate_runs()

    def test_display_percentile_retains_pre_exclusion_population(self):
        raw = {'AAA': {'mom': 1., 'roe': 2.}, 'BBB': {'mom': 2., 'roe': 1.},
               'CCC': {'mom': 3., 'roe': None}}
        scores = m3c.ranking.combined_scores(raw, {'mom': True}, {'roe': True})
        result = dict(scores=scores, picks=['AAA'], target={'AAA': 1.})
        context = object.__new__(m3c.Context)
        context.config = dict(market_criteria={'mom': True}, financial_criteria={'roe': True}, market_rule='leading')
        context.strategies = SimpleNamespace(target_for=lambda *a: result,
                                             _universe=lambda *a, **kw: ([], []),
                                             _rows=lambda *a: raw)
        rows = context.ranking_example('development', '2020-01-31')
        by_ticker = {row['ticker']: row for row in rows}
        self.assertEqual(set(by_ticker), {'AAA', 'BBB'})
        self.assertEqual(by_ticker['BBB']['pct_mom'], .5)
        self.assertEqual(by_ticker['BBB']['S_market'], .5)


if __name__ == '__main__':
    unittest.main(verbosity=2)
