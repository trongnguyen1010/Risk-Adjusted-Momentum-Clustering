"""Bounded real KBS pilot references, with explicit retrospective assumptions.

This is not a nationwide historical master or a vendor PIT timestamp service.
Policies remain frozen inputs, bound to reviewed source and reference hashes.
"""
from collections import Counter
from datetime import date, datetime, timedelta
from pathlib import Path
import uuid

from ..io import read_json, read_rows, write_json, write_rows, digest, now
from .promotion import verify_vendor, promote, trade_date


def pilot_calendar(days, start, end, fetched_at, safety_delay_minutes=120):
    """Market-open dates come exclusively from VNINDEX, never an equity."""
    days = sorted(set(days))
    if not days or any(date.fromisoformat(d).weekday() > 4 for d in days):
        raise ValueError("invalid benchmark sessions")
    ends = {d[:7]: d for d in days}
    rows = []
    d, last = date.fromisoformat(start), date.fromisoformat(end)
    opened = set(days)
    while d <= last:
        day = d.isoformat()
        close = datetime.fromisoformat(day + "T15:00:00+07:00")
        decision = close + timedelta(minutes=safety_delay_minutes)
        for exchange in ("HOSE", "HNX"):
            rows.append(dict(exchange=exchange, trade_date=day, is_open=day in opened,
                             is_month_end=day in opened and ends[day[:7]] == day,
                             open_at=day + "T09:00:00+07:00", close_at=close.isoformat(),
                             decision_at=decision.isoformat(), available_at=day + "T08:00:00+07:00",
                             source="research_assumption:benchmark_derived_VNINDEX", fetched_at=fetched_at))
        d += timedelta(days=1)
    return rows


def prepare(vendor, template_path, identity_path, root):
    """Freeze references/policy into a fresh run, refusing unreviewed vendor bytes."""
    vendor, root = Path(vendor).resolve(), Path(root).resolve()
    policy = read_json(template_path)
    manifest, documents = verify_vendor(vendor, policy)
    if manifest["synthetic"]:
        raise ValueError("real pilot cannot consume synthetic vendor")
    cfg = manifest["config"]
    if cfg["start"] != "2023-01-01" or cfg["end"] != "2025-12-31":
        raise ValueError("reviewed pilot reference interval is 2023-2025")
    evidence = read_json(identity_path)
    if set(cfg["symbols"]) != set(evidence):
        raise ValueError("pilot symbols do not match reviewed identities")
    listing = {r["symbol"]: r for d in documents if d["job"]["kind"] == "listing" for r in d["records"]}
    directory = root / "data/real_pilots" / ("real-pilot-" + uuid.uuid4().hex[:12])
    directory.mkdir(parents=True, exist_ok=False)
    stamp = now()
    master = []
    for symbol, item in sorted(evidence.items()):
        current = listing[symbol]
        if current["exchange"] != item["exchange"] or not item["evidence"]:
            raise ValueError("identity evidence/current exchange mismatch: " + symbol)
        master.append(dict(security_id=item["security_id"], ticker=symbol, company_name=current["organ_name"],
                           exchange=item["exchange"], listing_date=None, delisting_date=None,
                           valid_from=cfg["start"], valid_to="2026-01-01", available_at=cfg["start"]+"T00:00:00+07:00",
                           sector=None, industry=None, currency="VND", price_unit="VND",
                           identity_status="provisional_verified_for_pilot", source="VSD+KBS:pilot_identity_assumption", fetched_at=stamp))
    benchmark_days = [trade_date(r["time"], 420) for d in documents if d["job"]["kind"] == "index" for r in d["records"]]
    if len(benchmark_days) != len(set(benchmark_days)):
        raise ValueError("duplicate benchmark dates")
    benchmark = {trade_date(r["time"],420):r["close"] for d in documents if d["job"]["kind"] == "index" for r in d["records"]}
    cross_checks = {"VNINDEX_2025-07-18": abs(benchmark.get("2025-07-18",0)-1497.28)<0.02,
                    "VNINDEX_2025-12-31": abs(benchmark.get("2025-12-31",0)-1784.49)<0.02,
                    "Tet_2025_closed": all("2025-01-"+str(day) not in benchmark for day in range(27,32)),
                    "Tet_2025_reopen": "2025-02-03" in benchmark}
    write_json(directory / "cross_checks.json",dict(data_mode="real",checks=cross_checks,evidence="docs/data/kbs_pilot_semantics.md E3/E7 and HNX/VIX calendar"))
    if not all(cross_checks.values()):
        raise ValueError("benchmark/reference cross-check failed; inspect " + str(directory))
    calendar = pilot_calendar(benchmark_days, cfg["start"], cfg["end"], stamp, policy["availability_policy"]["safety_delay_minutes"])
    observations = [dict(kind="equity", symbol=d["job"]["symbol"], trade_date=trade_date(r["time"],420), trading_status="normal")
                    for d in documents if d["job"]["kind"] == "equity" for r in d["records"] if r.get("volume",0) > 0]
    # 'normal' here means an observed positive-volume bar; it does not certify
    # continuous tradability, order fills or the absence of intraday halts.
    write_json(directory / "identity_evidence.json", evidence)
    policy["references"] = {}
    for name, rows in dict(securities=master, trading_calendar=calendar, observations=observations,
                           corporate_actions=[], risk_free_rate=[]).items():
        path = directory / "references" / (name + ".jsonl")
        write_rows(path, rows)
        policy["references"][name] = dict(path=path.relative_to(directory).as_posix(), sha256=digest(path.read_bytes()),
                                            evidence=["docs/data/kbs_pilot_semantics.md", "identity_evidence.json", policy["methodology"]])
    write_json(directory / "policy.json", policy)
    canonical, result = promote(vendor, directory / "policy.json", root)
    write_json(directory / "lineage.json", dict(data_mode="real", vendor_run_id=vendor.name,
                                                canonical_run_id=canonical.name, promotion_status=result["status"]))
    return directory, canonical, result


def summarize(directory, vendor, canonical, feature_run, experiment, root):
    """Write inspectable acceptance evidence; never use a profitability threshold."""
    from .planning import pilot_report
    from ..io import atomic_write
    tables = {p.stem: read_rows(p) for p in (feature_run / "clean").glob("*.jsonl")}
    features = read_rows(feature_run / "features/monthly.jsonl")
    transitions = read_rows(experiment / "transitions.jsonl")
    snapshots = sorted({r["as_of_date"] for r in features})
    fields = ["mom_21","mom_63","mom_126","mom_252","vol_63","beta_126","mdd_126","ram_63"]
    eligibility = {day:{key:sum(r[key] is not None for r in features if r["as_of_date"] == day) for key in fields} for day in snapshots}
    counts = Counter()
    for row in transitions:
        counts[(row["from_cluster"],row["to_cluster"])] += row["count"]
    k = read_json(experiment / "manifest.json")["config"]["clustering"]["k"]
    matrix = [[counts[i,j] for j in range(k)] for i in range(k)]
    rates = [[v/sum(row) if sum(row) else None for v in row] for row in matrix]
    report = pilot_report(experiment)
    result = dict(data_mode="real", label="PILOT RESULT — NOT FINAL THESIS RESULT", vendor_run_id=vendor.name,
                  canonical_run_id=canonical.name, feature_run_id=feature_run.name, experiment_run_id=experiment.name,
                  symbols=sorted({r["ticker"] for r in tables["prices_daily"]}),
                  dates=[min(r["trade_date"] for r in tables["prices_daily"]),max(r["trade_date"] for r in tables["prices_daily"])],
                  trading_sessions=len(tables["benchmark_daily"]), benchmark="VNINDEX", eligibility_by_month=eligibility,
                  latest_eligible=eligibility[snapshots[-1]], transition_counts=matrix, transition_rates=rates,
                  shared_security_transitions=sum(map(sum,matrix)), acceptance=report,
                  promotion=read_json(canonical / "manifest.json"), performance=read_json(experiment / "performance.json"))
    em = read_json(experiment / "manifest.json")
    result.update(monthly_feature_snapshots=len(snapshots), monthly_cluster_snapshots=em["n_snapshots"],
                  assignments=em["n_assignments"], cluster_k=k,
                  missing_sessions=len(read_json(feature_run/"quality/coverage.json")["missing_sessions"]))
    write_json(directory / "result.json", result)
    promotion = result["promotion"]
    nav = read_rows(experiment / "backtests/cluster.jsonl")
    text = ["# REAL DATA STATUS", "", "data_mode = real", "", "**PILOT RESULT — NOT FINAL THESIS RESULT**", "",
            f"Vendor run: `{vendor.name}`", f"Canonical run: `{canonical.name}`", f"Feature run: `{feature_run.name}`", f"Experiment: `{experiment.name}`", "",
            "Symbols: " + ", ".join(result["symbols"]), f"Date range: {result['dates'][0]} → {result['dates'][1]}",
            f"Trading sessions: {result['trading_sessions']}; benchmark: VNINDEX", "",
            "## SEMANTICS RESOLVED", "", "See [evidence and mapping table](../../../docs/data/kbs_pilot_semantics.md).", "",
            "- Equity price multiplier=1000; index multiplier=1; volume multiplier=1 shares.",
            "- vendor_adjusted: adj_close present; raw OHLC null. Technical adjusted-price proxy, not certified total return.",
            "- va omitted; traded_value/liquidity_21 null and optional.",
            "- Session day normalized in +07:00; available_at_method=research_assumption, EOD + 120 min, next-session execution.",
            "- calendar_method=benchmark_derived; identity_status=provisional_verified_for_pilot; rf_annual=0 assumption.", "",
            "## PIPELINE RESULT", "",
            f"Promotion {promotion['quality']}: input {promotion['records_input']}, accepted {promotion['records_accepted']}, quarantined {promotion['records_quarantined']}, warnings {len(promotion['warnings'])}, blocking errors {promotion['blocking_errors']}.",
            f"Reference rows: securities {len(tables['securities'])}, calendar {len(tables['trading_calendar'])}; corporate_actions/risk_free_rate empty.",
            f"QC missing sessions: {result['missing_sessions']}; features: {len(features)} rows / {len(snapshots)} monthly snapshots.",
            f"Clustering: {em['n_snapshots']} monthly snapshots, k={k}, {em['n_assignments']} assignments.",
            f"Transitions: {sum(map(sum,matrix))} shared-security month-to-month observations.",
            f"Backtest: {nav[0]['date']} → {nav[-1]['date']}, {len(nav)} valuation sessions; next-close fractional return-space.",
            f"Acceptance: {report['status']}", "", "Latest eligible securities by feature:", "",
            "| Feature | Securities |", "|---|---:|"]
    text.extend(f"| {key} | {value} |" for key,value in result["latest_eligible"].items())
    text.extend(["", "Transition count matrix (aligned cluster labels):", "", "| From / To | " + " | ".join(map(str,range(k))) + " |", "|---|"+"---:|"*k])
    text.extend("| "+str(i)+" | "+" | ".join(map(str,row))+" |" for i,row in enumerate(matrix))
    text.extend(["", "Performance (development pilot, not investment recommendation):", "", "| Strategy | Cumulative net return | Annualized return | Maximum drawdown |", "|---|---:|---:|---:|"])
    for name, values in result["performance"].items():
        text.append(f"| {name} | {values['cumulative_return']:.2%} | {values.get('annualized_return',float('nan')):.2%} | {values['maximum_drawdown']:.2%} |")
    text.extend(["", "## REMAINING LIMITATIONS", ""]+ ["- "+w for w in promotion["warnings"]]+["", "Config, source snapshot and artifact hashes are saved with the experiment. Synthetic fixtures are excluded from this result."])
    atomic_write(directory / "report.md", ("\n".join(text)+"\n").encode("utf-8"))
    write_json(Path(root)/"data/real_pilots/latest.json", dict(data_mode="real", result_path=str(directory/"result.json"), experiment_path=str(experiment)))
    return result
