"""Phân rã đợt giảm Holdout 2024 từ run đã seal; không tune hoặc tạo strategy mới."""
from collections import Counter, defaultdict
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))

from m3c import Context, PIN, ROOT, compare_rows, equal, grouped, read_json, sha, write_json
from delta_t1.m3.engine import Portfolio, rebalance, revalue
from delta_t1.m3.prices import PriceBook

START, END = '2024-05-02', '2024-11-01'
BASE = ROOT / 'M3/reproduction/20261104T150049600949Z'


def fmt(value, percent=False):
    if value is None:
        return '—'
    return (f'{value * 100:.2f}%' if percent else f'{value:.6f}').replace('.', ',')


def points(value):
    number = round(value * 100, 2)
    return f'{number if number else 0:.2f}'.replace('.', ',')


def analyze():
    # Reuse the full input hash proof; Context rejects changed fingerprints/metadata/source.
    os.environ['M3C_OUTPUT_DIR'] = str(BASE)
    ctx = Context()
    proof_path = BASE / 'preflight.json'
    output = ROOT / 'M3/reproduction' / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + '-holdout-diagnosis')
    output.mkdir(parents=True)
    snapshot = Path(ctx.proof['limits']['path'])
    assert sha(snapshot) == ctx.proof['limits']['sha256']
    limits = {(t, d): (r, c, f) for t, d, r, c, f in read_json(snapshot)}
    info = ctx.runs['holdout']; manifest = info['manifest']
    nav = {r['date']: float(r['nav']) for r in ctx.read('holdout', 'nav', 'combined')}
    benchmark = {r['date']: float(r['nav']) for r in ctx.read('holdout', 'benchmark_vnindex')}
    dates = list(nav)
    book = PriceBook(dates, ctx.calendar, limits=limits, segment_start=manifest['segment_start'], segment_end=manifest['segment_end_date'])
    assert len(book.flags) == info['metrics']['adj_glitches_repaired']
    targets = grouped(ctx.read('holdout', 'targets', 'combined'), 'execution_date')
    audits = grouped(ctx.read('holdout', 'universe_audit', 'combined'), 'decision_date')
    ledgers = grouped(ctx.read('holdout', 'trade_ledger', 'combined'), 'date')
    holdings = grouped(ctx.read('holdout', 'holdings', 'combined'), 'date')
    turnovers = {r['date']: float(r['turnover']) for r in ctx.read('holdout', 'turnover', 'combined')}
    pf = Portfolio(); previous = None
    periods = []; contributions = []; opportunities = []; opportunity_coverage = []; execution_cases = []
    peak_nav = nav[START]
    for date in dates:
        stale = revalue(pf, date, book.price)
        equal(pf.nav, nav[date], ('replay NAV', date))
        if previous and START <= previous['date'] < END:
            start = previous['date']; start_nav = nav[start]
            pnl = pf.nav - start_nav
            equal(sum(pf.values.get(t, 0.) - value for t, value in previous['values'].items()), pnl, 'attribution reconciliation')
            keys = sorted(set(previous['weights']) | set(previous['goal']))
            local = []; unknown = []
            for ticker in keys:
                if ticker == 'CASH':
                    continue
                weight = previous['weights'].get(ticker, 0.)
                goal = previous['goal'].get(ticker, 0.)
                p0 = previous['marks'].get(ticker) or book.price(ticker, start)
                p1 = pf.marks.get(ticker) if ticker in pf.values else book.price(ticker, date)
                actual = pf.values.get(ticker, 0.) - previous['values'].get(ticker, 0.)
                r = p1 / p0 - 1 if p0 and p1 else None
                intended = start_nav * goal * r if r is not None else None
                gap = start_nav * (weight - goal) * r if r is not None else None
                if intended is None and goal:
                    unknown.append(dict(ticker=ticker, goal=goal))
                if r is not None:
                    equal(actual, start_nav * weight * r, ('ticker PnL', ticker, start, date))
                    equal(actual, intended + gap, ('goal + deviation', ticker, start))
                action = previous['ledger'].get(ticker, {})
                local.append(dict(start=start, end=date, decision_date=previous['decision'], ticker=ticker,
                                  actual_weight=weight, goal_weight=goal, start_mark=p0, end_mark=p1,
                                  valuation_return=r, actual_pnl=actual, goal_pnl=intended, deviation_pnl=gap,
                                  contribution_to_window_return=actual / peak_nav,
                                  ledger_status=action.get('status', 'NO_ACTION'), side=action.get('side', ''),
                                  price_stale_at_end=ticker in stale))
            equal(sum(row['actual_pnl'] for row in local), pnl, 'ticker totals')
            cash = previous['weights']['CASH']
            selected = set(previous['goal'])
            coverage = Counter()
            for market in ctx.market[previous['decision']]:
                ticker = market['ticker']
                if market['liquidity'] == 'ILLIQUID':
                    coverage['illiquid_excluded'] += 1
                    continue
                p0 = book.price(ticker, start); p1 = book.price(ticker, date)
                if not p0 or not p1:
                    coverage['missing_endpoint_price'] += 1
                    continue
                saved_missing = book.limit_missing.copy()
                executable = book.tradable(ticker, start, 'BUY')
                book.limit_missing = saved_missing
                if not executable:
                    coverage['not_buy_executable_at_start'] += 1
                    continue
                coverage['valid_observed_buyable'] += 1
                forward_return = p1 / p0 - 1
                if ticker in selected:
                    coverage['selected'] += 1
                    continue
                coverage['unselected'] += 1
                if forward_return <= 0:
                    continue
                coverage['unselected_positive'] += 1
                audit = previous['audit'][ticker]
                reason = 'RANK_BELOW_TOP_SHARE' if audit['in_candidate_universe'] else audit['reason']
                assert reason
                opportunities.append(dict(start=start, end=date, decision_date=previous['decision'], ticker=ticker,
                                          observed_forward_return=forward_return, exclusion_reason=reason,
                                          market_eligible=audit['market_eligible'], financial_eligible=audit['financial_eligible'],
                                          financial_year=audit['financial_year'], flags=audit['flags'],
                                          rank=previous['ranks'].get(ticker), score=previous['scores'].get(ticker),
                                          selected_score_cutoff=previous['score_cutoff'],
                                          already_held=previous['weights'].get(ticker, 0.) > 0,
                                          volume_at_start=book.volume[ticker, start]))
            opportunity_coverage.append(dict(start=start, end=date, **coverage))
            statuses = Counter(r['status'] for r in previous['ledger'].values())
            max_stock = max((w, t) for t, w in previous['weights'].items() if t != 'CASH')
            audit_rows = list(previous['audit'].values())
            market_pool = sum(a['market_eligible'] for a in audit_rows)
            joint = sum(a['market_eligible'] and a['financial_eligible'] for a in audit_rows)
            periods.append(dict(decision_date=previous['decision'], start=start, end=date,
                                candidates=previous['candidates'], N_selected=len(selected),
                                market_pool=market_pool, joint_before_fc=joint,
                                all_fc_missing_removed=joint - previous['candidates'],
                                financial_exclusions_in_market_pool=dict(Counter(a['reason'] for a in audit_rows if a['market_eligible'] and not a['in_candidate_universe'])),
                                actual_stocks=sum(t != 'CASH' for t in previous['weights']),
                                cash_ratio=cash, max_target_weight=max(previous['goal'].values(), default=0),
                                largest_actual_weight=max_stock[0], largest_actual_ticker=max_stock[1],
                                actual_return=pnl / start_nav, benchmark_return=benchmark[date] / benchmark[start] - 1, actual_pnl=pnl,
                                goal_pnl=sum(r['goal_pnl'] for r in local if r['goal_pnl'] is not None),
                                deviation_pnl=sum(r['deviation_pnl'] for r in local if r['deviation_pnl'] is not None),
                                unknown_goal_returns=unknown, ledger_statuses=dict(statuses)))
            contributions.extend(local)
        if date == dates[-1]:
            continue
        rows = targets[date]
        decision = rows[0]['decision_date']
        result = None
        if START <= date < END:
            generated, result = ctx.target_rows('holdout', 'combined', decision)
            compare_rows(generated, rows, ('target verified', decision))
            compare_rows(result['audit'], audits[decision], ('audit verified', decision))
        if rows[0]['status'] == 'UNIVERSE_TOO_SMALL':
            target = ctx.strategies.target_for('combined', decision)['engine_target'](pf.weights())
        else:
            target = {r['ticker']: float(r['target_weight']) for r in rows if r['ticker']}
        book.limit_missing = set()
        ledger, turnover = rebalance(pf, target, date, book.price, book.tradable)
        for row in ledger:
            row['flag'] = 'LIMIT_DATA_MISSING' if row['status'] in ('BUY_FAILED', 'SELL_FAILED') and (row['ticker'], date) in book.limit_missing else ''
        compare_rows(ledger, ledgers[date], ('ledger', date))
        compare_rows([dict(date=date, ticker=t, weight=w) for t, w in pf.weights().items()], holdings[date], ('holdings', date))
        equal(turnover, turnovers[date], ('turnover', date))
        if START <= date < END:
            for trade in ledger:
                if trade['status'] not in ('BUY_FAILED', 'SELL_FAILED', 'SCALED'):
                    continue
                ticker = trade['ticker']
                raw, ceiling, floor = limits.get((ticker, date), (None, None, None))
                volume = book.volume.get((ticker, date))
                reasons = []
                if book.price(ticker, date) is None:
                    reasons.append('Thiếu current_price')
                if volume is None:
                    reasons.append('Thiếu volume')
                elif volume == 0:
                    reasons.append('volume=0')
                if trade['side'] == 'SELL' and raw is not None and floor and raw <= floor:
                    reasons.append('raw_close<=floor')
                if trade['side'] == 'BUY' and raw is not None and ceiling and raw >= ceiling:
                    reasons.append('raw_close>=ceiling')
                if trade['status'] == 'SCALED':
                    reasons.append('Giảm đồng tỷ lệ do cash không đủ')
                assert reasons, trade
                execution_cases.append(dict(date=date, **{k: trade[k] for k in ['ticker', 'side', 'status', 'pre_weight', 'target_weight', 'intended', 'executed', 'scale']},
                                            actual_weight=pf.weights().get(ticker, 0.), volume=volume,
                                            raw_close=raw, ceiling=ceiling, floor=floor, reasons=reasons))
        ranks = {}; scores = {}; cutoff = None
        if result:
            from delta_t1.m3.ranking import select_top
            values = result.get('scores', {})
            liquidity = {r['ticker']: r['features'].get('liquidity_21') for r in ctx.market[decision]}
            ranks = {t: rank for t, rank, _ in select_top({t: s['score'] for t, s in values.items()}, liquidity, 1.)}
            scores = {t: s['score'] for t, s in values.items()}
            cutoff = min((scores[t] for t in target), default=None)
        previous = dict(date=date, decision=decision, values=pf.values.copy(), marks=pf.marks.copy(),
                        weights=pf.weights(), goal=target, candidates=int(rows[0]['candidates']),
                        ledger={r['ticker']: r for r in ledger},
                        audit={r['ticker']: r for r in (result['audit'] if result else [])},
                        ranks=ranks, scores=scores, score_cutoff=cutoff)
    assert len(periods) == 6 and periods[0]['start'] == START and periods[-1]['end'] == END
    cdr_missed = next(r for r in opportunities if r['ticker'] == 'CDR' and r['start'] == '2024-07-01')
    assert cdr_missed['exclusion_reason'] == 'RANK_BELOW_TOP_SHARE' and cdr_missed['rank'] == 9
    actual_pnl = nav[END] - nav[START]
    equal(sum(r['actual_pnl'] for r in periods), actual_pnl, 'window PnL')
    equal(actual_pnl / peak_nav, info['metrics']['combined']['max_drawdown'], 'window equals observed MDD')
    by_ticker = defaultdict(lambda: dict(actual_pnl=0., periods=0, max_weight=0., goal_pnl=0., deviation_pnl=0.))
    by_status = defaultdict(float)
    for row in contributions:
        item = by_ticker[row['ticker']]
        item['actual_pnl'] += row['actual_pnl']; item['periods'] += 1
        item['max_weight'] = max(item['max_weight'], row['actual_weight'])
        for key in ['goal_pnl', 'deviation_pnl']:
            if row[key] is not None:
                item[key] += row[key]
        if row['deviation_pnl'] is not None:
            by_status[row['ledger_status']] += row['deviation_pnl']
    ranked = sorted([dict(ticker=t, **v, window_contribution=v['actual_pnl'] / peak_nav) for t, v in by_ticker.items()], key=lambda r: r['actual_pnl'])
    unknown = [dict(start=r['start'], **u) for r in periods for u in r['unknown_goal_returns']]
    if not unknown:
        equal(sum(r['goal_pnl'] + r['deviation_pnl'] for r in periods), actual_pnl, 'full decomposition')
    ctx.finish()
    evidence = dict(status='PASS', window=dict(start=START, end=END, selection='đỉnh–đáy max drawdown quan sát sau đánh giá, chỉ để chẩn đoán',
                    start_nav=nav[START], end_nav=nav[END], return_=actual_pnl / peak_nav,
                    benchmark_return=benchmark[END] / benchmark[START] - 1),
                    periods=periods, ticker_totals=ranked, contributions=contributions,
                    goal_pnl_total=sum(r['goal_pnl'] for r in periods), deviation_pnl_total=sum(r['deviation_pnl'] for r in periods),
                    unknown_goal_returns=unknown, deviation_by_status=dict(by_status),
                    missed_positive_observations=opportunities, opportunity_coverage=opportunity_coverage,
                    primary_reasons=dict(Counter(r['exclusion_reason'] for r in opportunities)), execution_cases=execution_cases,
                    source_run=manifest['run_id'], source_commit=manifest['git_commit'], config_sha256=manifest['config_sha256'],
                    source_preflight=str(proof_path.relative_to(ROOT)).replace('\\', '/'), source_preflight_sha256=sha(proof_path),
                    input_hashes=manifest['inputs_sha256'], source_seal_sha256=sha(ROOT / PIN['runs']['holdout']['seal']),
                    source_pins_sha256=sha(ROOT / 'M3/sources.json'),
                    analyzer_sha256=sha(Path(__file__)), canonical_preserved=True)
    write_json(output / 'analysis.json', evidence)
    report = render(evidence, output)
    report_path = ROOT / 'M3/reports/PHAN_TICH_BUOC_1_HOLDOUT_2024.md'
    report_path.write_text(report, encoding='utf-8')
    write_json(output / 'verification.json', dict(status='PASS', analysis_sha256=sha(output / 'analysis.json'),
               report_sha256=sha(report_path), analyzer_sha256=sha(Path(__file__)), official_replay='holdout ledger/holdings/NAV/turnover PASS',
               actual_contributions_reconcile=True, decomposition_complete=not unknown, canonical_preserved=True))
    print(json.dumps(dict(window=evidence['window'], losses=ranked[:8],
                          goal_pnl_total=evidence['goal_pnl_total'], deviation_pnl_total=evidence['deviation_pnl_total'],
                          deviation_by_status=dict(by_status), unknown_goal_returns=unknown,
                          primary_reasons=evidence['primary_reasons'], report=str(report_path), evidence=str(output)), ensure_ascii=False, indent=2))


def render(data, output):
    window = data['window']; base = window['start_nav']
    top3 = data['ticker_totals'][:3]
    top3_share = sum(r['actual_pnl'] for r in top3) / (window['end_nav'] - base)
    worst = min(data['periods'], key=lambda r: r['actual_return'])
    cdr_missed = next(r for r in data['missed_positive_observations'] if r['ticker'] == 'CDR' and r['start'] == '2024-07-01')
    cdr_held = next(r for r in data['contributions'] if r['ticker'] == 'CDR' and r['start'] == '2024-08-01')
    lines = ['# Phân tích Bước 1 và giao dịch — đợt giảm Holdout 2024', '',
             '## 1. Phạm vi và cách đọc', '',
             f'Phân tích đợt giảm từ **{START} đến {END}**, tức đỉnh–đáy max drawdown của Combined đã quan sát. '
             f'NAV giảm từ {fmt(base)} xuống {fmt(window["end_nav"])}, tương ứng {fmt(window["return_"], True)}. '
             f'VNINDEX trong đúng khoảng này có lợi suất {fmt(window["benchmark_return"], True)}. '
             'Đây là cửa sổ được chọn sau khi xem kết quả để giải thích tổn thất, không phải một mẫu đánh giá mới.', '',
             'Đóng góp từng mã = giá trị vị thế sau giao dịch × biến động mark đến kỳ kế tiếp. Cộng PnL theo '
             'đơn vị vốn đầu=1 rồi chia NAV tại đầu cửa sổ để ra điểm phần trăm của đợt giảm; không cộng trực tiếp '
             'các tỷ suất tháng. Tái sử dụng revalue/rebalance chính thức và đối chiếu toàn bộ Holdout với run sealed.', '',
             '## Nhận định chính', '',
             f'**Bước 1 là phần đáng chú ý chính trong đợt giảm này:** trên cùng đường vốn thực tế, phần phân bổ '
             f'theo goal đóng góp {points(data["goal_pnl_total"] / base)} điểm phần trăm, còn lệch phân bổ sau giao dịch '
             f'đóng góp thêm {points(data["deviation_pnl_total"] / base)} điểm phần trăm vào mức giảm '
             f'{fmt(window["return_"], True)}. Vì phần goal đã âm lớn, tổn thất không thể giải thích chỉ bằng lệnh thất bại. '
             'Đây là phép phân rã PnL, không phải tỷ lệ nguyên nhân hay lợi suất của một backtest giả định đã fill mọi lệnh.', '',
             f'**Rủi ro tập trung xuất hiện ngay trong target:** kỳ đầu cửa sổ chỉ chọn '
             f'{data["periods"][0]["N_selected"]} mã từ {data["periods"][0]["candidates"]} ứng viên, '
             f'goal mỗi mã {fmt(data["periods"][0]["max_target_weight"], True)}. Kỳ '
             f'{worst["start"]} → {worst["end"]} giữ {worst["actual_stocks"]} mã, giảm '
             f'{fmt(worst["actual_return"], True)}, trong khi VNINDEX giảm '
             f'{fmt(abs(worst["benchmark_return"]), True)}; lệch thực thi kỳ đó chỉ '
             f'{points(worst["deviation_pnl"] / base)} điểm phần trăm. '
             'Như vậy kỳ lỗ nặng nhất phát sinh ngay cả khi thực giữ khớp goal. N_min áp dụng cho số ứng viên, '
             'không bảo đảm danh mục thực giữ ít nhất mười mã.', '',
             '**Tổn thất tập trung vào ' + ', '.join(r['ticker'] for r in top3) + ':** ba mã này đóng góp lần lượt '
             + ', '.join(points(r['window_contribution']) for r in top3) + ' điểm phần trăm, tương ứng '
             + fmt(top3_share, True) + ' mức lỗ ròng của cửa sổ. Điều này gắn phần giảm lớn với các vị thế cụ thể, '
             'chưa chứng minh một filter riêng lẻ là sai.', '',
             '**Thực thi vẫn có ảnh hưởng riêng:** BUY_FAILED làm bỏ lỡ một số mức tăng; SELL_FAILED giữ vị thế '
             'cần giảm. Riêng CID ở kỳ 01/10 → 01/11 có tỷ trọng vượt goal do bán thất bại và tiếp tục giảm giá. '
             'Một số BUY_FAILED lại giúp tránh lỗ, nên cần cộng cả tác động có lợi và bất lợi thay vì coi mọi lệnh '
             'thất bại đều gây thiệt hại.', '',
             '**Có mã tăng bị loại ở cả gate cụm và xếp hạng:** CDR ở kỳ 01/07 → 01/08 thuộc Candidate Universe '
             f'nhưng xếp hạng {cdr_missed["rank"]}, ngoài top {worst["N_selected"]}, rồi tăng '
             f'{fmt(cdr_missed["observed_forward_return"], True)}. Kỳ sau, mã này được giữ với tỷ trọng '
             f'{fmt(cdr_held["actual_weight"], True)} và giảm {fmt(abs(cdr_held["valuation_return"]), True)}. '
             'Trường hợp này minh họa việc vào sau một đợt tăng rồi gặp đảo chiều, chưa chứng minh đây là quy luật '
             'chung của chiến lược. Đây là minh họa sau khi biết kết quả, không chứng minh có thể biết '
             'trước để chọn hoặc rằng nên sửa rule sau Holdout. Chưa đủ bằng chứng để quy riêng nguyên nhân '
             'cho Market filter, Financial filter hay cách chấm điểm.', '',
             '## 2. Những mã đóng góp tổn thất lớn nhất', '',
             '| Mã | PnL vốn chuẩn hóa | Đóng góp (điểm phần trăm) | Tỷ trọng thực giữ lớn nhất | Số khoảng quan sát |',
             '|---|---:|---:|---:|---:|']
    for row in data['ticker_totals'][:12]:
        lines.append(f'| {row["ticker"]} | {fmt(row["actual_pnl"])} | {points(row["window_contribution"])} | {fmt(row["max_weight"], True)} | {row["periods"]} |')
    lines += ['', 'Đóng góp dương của các mã khác có thể bù một phần tổn thất; tổng đóng góp mọi mã khớp chênh lệch NAV. '
              'Số khoảng không phải số lần mua. Tỷ trọng lớn nhất là tỷ trọng thực tế sau giao dịch trong cửa sổ.', '',
              '## 3. Tập ứng viên và độ tập trung danh mục theo kỳ', '',
              '| Decision | Khoảng nắm giữ | Ứng viên | N_selected | Mã thực giữ | Goal lớn nhất | Thực giữ lớn nhất | Cash | Return Combined | Return VNINDEX |',
              '|---|---|---:|---:|---:|---:|---|---:|---:|---:|']
    for row in data['periods']:
        lines.append(f'| {row["decision_date"]} | {row["start"]} → {row["end"]} | {row["candidates"]} | {row["N_selected"]} | '
                     f'{row["actual_stocks"]} | {fmt(row["max_target_weight"], True)} | {row["largest_actual_ticker"]}: '
                     f'{fmt(row["largest_actual_weight"], True)} | {fmt(row["cash_ratio"], True)} | {fmt(row["actual_return"], True)} | {fmt(row["benchmark_return"], True)} |')
    lines += ['', 'Các gate ở Bước 1 thu hẹp tập mã như sau; đây là số đếm theo từng decision, không phải số mã duy nhất:', '',
              '| Decision | Market Eligible Pool | Giao Market/Financial trước FC missing | Bị loại vì thiếu toàn bộ FC | Candidate cuối | N_selected |',
              '|---|---:|---:|---:|---:|---:|']
    for row in data['periods']:
        lines.append(f'| {row["decision_date"]} | {row["market_pool"]} | {row["joint_before_fc"]} | {row["all_fc_missing_removed"]} | '
                     f'{row["candidates"]} | {row["N_selected"]} |')
    lines += ['', 'Số mã giảm qua gate mô tả cơ chế thu hẹp tập chọn; chưa đo tác động nhân quả của việc nới/bỏ gate. '
              'Chi tiết lý do Financial trong Market pool được lưu theo kỳ trong evidence.', '',
              '## 4. Tách goal ở Bước 1 và sai lệch sau thực thi', '',
              'Đây là phép phân rã tại từng kỳ trên **cùng NAV thực tế đầu kỳ**, không phải backtest một chiến lược '
              'khác. Phần goal = NAV × goal_weight × return của mã; phần sai lệch = NAV × (actual_weight − goal_weight) '
              '× return. Hai phần cộng lại bằng PnL thực tế khi đủ mark. Cash có return 0 theo contract. '
              'Mark được carry đúng policy cho vị thế cũ PRICE_STALE; thiếu giá của mã chưa nắm giữ không tự thay bằng zero.', '',
              f'- Đóng góp theo goal trên cùng vốn thực tế: **{points(data["goal_pnl_total"] / base)} điểm phần trăm**.',
              f'- Đóng góp do sai lệch phân bổ sau giao dịch: **{points(data["deviation_pnl_total"] / base)} điểm phần trăm**.',
              f'- Tổng thực tế: **{fmt(window["return_"], True)}**.',
              f'- Số quan sát thiếu return để phân rã goal: **{len(data["unknown_goal_returns"])}**.', '',
              'Các số đóng góp trên quy về một mẫu số chung, không phải lợi suất cộng dồn của danh mục giả định '
              'đã fill toàn bộ target. Dấu dương ở phần sai lệch nghĩa là thực thi giúp kết quả ít lỗ hơn so với phần goal '
              'được quy đổi trên cùng đường vốn thực tế; dấu âm nghĩa là làm kết quả xấu hơn.', '',
              '| Trạng thái ledger | Đóng góp của sai lệch so với goal (điểm phần trăm) |', '|---|---:|']
    for status, value in sorted(data['deviation_by_status'].items()):
        lines.append(f'| {status} | {points(value / base)} |')
    lines += ['', '| Ngày | Mã | Trạng thái | Goal | Thực giữ | Dữ kiện chặn/giảm lệnh |', '|---|---|---|---:|---:|---|']
    for row in data['execution_cases']:
        lines.append(f'| {row["date"]} | {row["ticker"]} | {row["status"]} | {fmt(row["target_weight"], True)} | '
                     f'{fmt(row["actual_weight"], True)} | {"; ".join(row["reasons"])} |')
    lines += ['', '## 5. Mã tăng nhưng không nằm trong target', '',
              'Phạm vi rà soát là các mã không ILLIQUID tại decision, có đủ giá điều chỉnh ở hai đầu khoảng và '
              'BUY executable tại đầu khoảng theo Q12. Bảng dưới chọn các quan sát return dương cao nhất **sau khi '
              'đã biết kết quả**. Ticker có thể vẫn được giữ từ kỳ trước dù không có trong target; xem cột thực giữ cũ. '
              'Lý do là lý do chính trong audit, các gate có thể cùng loại một mã.', '',
              '| Mã | Khoảng | Return quan sát | Lý do không vào target | Rank nếu có | Thực giữ cũ |',
              '|---|---|---:|---|---:|---|']
    for row in sorted(data['missed_positive_observations'], key=lambda r: r['observed_forward_return'], reverse=True)[:15]:
        lines.append(f'| {row["ticker"]} | {row["start"]} → {row["end"]} | {fmt(row["observed_forward_return"], True)} | '
                     f'{row["exclusion_reason"]} | {row["rank"] if row["rank"] else "—"} | {"Có" if row["already_held"] else "Không"} |')
    lines += ['', '| Lý do chính | Số mã/kỳ return dương không có trong target |', '|---|---:|']
    for reason, count in sorted(data['primary_reasons'].items(), key=lambda x: -x[1]):
        lines.append(f'| {reason} | {count} |')
    lines += ['', 'Đây là số quan sát mã/kỳ, không phải số mã duy nhất. Có mã tăng bị loại không tự chứng minh bộ lọc '
              'sai hoặc rằng có thể biết trước để mua. Chưa phân rã theo tỷ trọng VNINDEX, chưa kiểm định tác dụng nhân quả '
              'của từng filter. Return quan sát vẫn có giới hạn giá điều chỉnh của nhà cung cấp; không dùng bảng này để tune '
              'rule sau Holdout.', '', '## 6. Evidence và giới hạn', '',
              f'- Run nguồn: `{data["source_run"]}`, code `{data["source_commit"]}`.',
              f'- Config SHA256: `{data["config_sha256"]}`.',
              f'- [Phân rã từng kỳ/mã và coverage](../{output.relative_to(ROOT / "M3").as_posix()}/analysis.json).',
              f'- [Kiểm tra đối chiếu](../{output.relative_to(ROOT / "M3").as_posix()}/verification.json).',
              '- Dùng evidence input hash có kiểm tra fingerprint từ phiên M3-C đã chạy; không scan lại C8 không cần thiết.',
              '- Phân tích chỉ giải thích đợt giảm 2024, không giải thích toàn bộ chênh lệch với VNINDEX trong Holdout.',
              '- Giới hạn vendor-adjusted/price index, mark stale, phí/slippage 0 và vintage tài chính tiếp tục áp dụng.',
              '- Không thay config, strategy, target, input hoặc run/seal canonical. Không tạo official backtest mới.', '']
    return '\n'.join(lines)


if __name__ == '__main__':
    analyze()
