"""Trình bày báo cáo từ kết quả M3-A đã niêm phong; không tính lại strategy."""
from pathlib import Path


def pct(value):
    return '—' if value is None else f'{value * 100:.2f}%'.replace('.', ',')


def pp(value):
    return f'{abs(value) * 100:.2f}'.replace('.', ',')


def report_text(ctx):
    from m3c import NAMES, ROOT
    cfg = ctx.config
    dev = ctx.runs['development']['metrics']; hold = ctx.runs['holdout']['metrics']
    dc, hc = dev['combined'], hold['combined']
    periods = {s: len(ctx.decisions(s)) for s in ctx.runs}
    counts = {s: ctx.runs[s]['manifest']['counts']['combined'] for s in ctx.runs}
    lines = [
        '# Báo cáo kỹ thuật M3 — Development và Holdout', '',
        '**Phạm vi:** phần lịch sử đã tái lập; Final Evaluation `NOT_READY`. M3-C tổng thể `PARTIAL`.', '',
        'Báo cáo này được sinh bằng Notebook 03 và `M3/m3c_report.py` từ metrics/canonical outputs đã seal. '
        'Số liệu được định dạng từ tệp nguồn, không chép tay. Báo cáo tiến độ công việc riêng ở '
        '[REPORT_BACKTEST.md](../../docs/REPORT_BACKTEST.md).', '',
        '## 1. Mục tiêu và câu hỏi nghiên cứu', '',
        'Đánh giá quy tắc kết hợp trạng thái Market và Financial tại tầng danh mục: Combined có tạo lợi thế '
        'về lợi suất và rủi ro so với bốn strategy đối chứng và VNINDEX hay không? '
        'Chất lượng cụm, độ ổn định cụm và hiệu quả danh mục là các lớp đánh giá độc lập. '
        'Kết quả danh mục không được dùng để chọn lại k, algorithm hoặc rule đã khóa.', '',
        '## 2. Nguồn dữ liệu, phiên bản và khả năng truy nguyên', '',
        f'- Code nguồn các run: `{ctx.identity["source_commit"]}`.',
        f'- Code thực thi notebook: `{ctx.identity["execution_commit"]}`; các module M3 đã đối chiếu với commit nguồn.',
        f'- Config: `{ctx.runs["development"]["manifest"]["config"]}`, status `{cfg["status"]}`.',
        f'- SHA256 config: `{ctx.runs["development"]["manifest"]["config_sha256"]}`.',
        '- Dataset revision: `08c24867b11177072bfe457a4623a38abf9bbc48`.', '',
        '| Đầu vào | Path local từ gốc repository | SHA256 |', '|---|---|---|',
    ]
    for key, record in ctx.proof['inputs'].items():
        lines.append(f'| {key} | `{record["path"]}` | `{record["sha256"]}` |')
    lines += ['', '| Segment | Run | Seal SHA256 |', '|---|---|---|']
    for segment, pin in __import__('m3c').PIN['runs'].items():
        run = ctx.runs[segment]['manifest']['run_id']
        lines.append(f'| {segment} | [{run}](../../data/experiments/m3/{segment}/{run}/manifest.json) | `{pin["seal_sha256"]}` |')
    lines += ['', 'Notebook 01 kiểm tra identity/hash và PIT mẫu. Notebook 02 đối chiếu targets/audit đủ từng mã/ngày. '
              'Notebook 03 đối chiếu engine và metrics. Evidence từng lần chạy nằm trong `M3/reproduction/`; '
              'các file canonical/seal nguồn được kiểm tra giữ nguyên.', '',
              '## 3. Kiến trúc hai hệ phân cụm', '',
              'Market dùng mô hình A của bundle v4, k=3, đọc các snapshot thị trường đã có. '
              'Financial dùng B-PIT theo công thức B v4, chín chỉ số, winsorize/z-score và K-Means k=3 '
              'tại cutoff từng FY; tâm cụm, preprocessing và thứ tự cụm được đóng băng. '
              'M3 không gộp hai hệ thành mô hình clustering mới và notebook không fit lại chúng. '
              'B v4 chỉ là đối chiếu ARI trong artifact B-PIT.', '',
              '## 4. Căn thời gian và PIT', '',
              'Nguồn availability FY trước 2022 dùng LAG_RULE ngày 30/06 năm kế tiếp, usable từ phiên giao dịch '
              'quan sát đầu tiên sau ngày đó. Từ FY2022, dùng ngày gửi CafeF và phiên usable tiếp theo theo Q-date. '
              'Runtime chọn FY mới nhất đã usable, kiểm tra stale theo config và metadata/cutoff model. '
              'FY mới đã usable nhưng model chưa sẵn sàng không được fallback sang FY cũ. '
              'Điều kiện ngày này không loại bỏ giới hạn vintage/revision của snapshot Indicators.', '',
              f'Stale tối đa theo config: {cfg["stale_months"]} tháng. Notebook gọi `universe.financial_state` '
              'và `Strategies.target_for`; không viết quy tắc PIT thứ hai.', '',
              '## 5. Candidate Universe và đối chứng', '',
              f'Combined dùng Market rule `{cfg["market_rule"]}` giao với Financial rule `{cfg["financial_rule"]}`, '
              'sau các gate thanh khoản, sector, availability, model cutoff và tính đầy đủ tiêu chí. '
              'Financial loại BANK/SECURITIES/INSURANCE do không có nhãn B phù hợp. '
              'Thiếu một phần tiêu chí được chấm percentile trung tính 0,5 và ghi flag; thiếu toàn bộ FC bị loại '
              'trước N_min. Universe audit lưu lý do theo từng mã/ngày.', '',
              '- Market-only: chọn theo cụm Market dẫn dắt và điểm Market.',
              '- Financial-only: Financial Eligible Pool giao traded universe; chấm điểm Financial.',
              '- Equal-weight: chia đều tập mã không bị ILLIQUID của snapshot.',
              '- Momentum-only: top-share theo mom_126 trên tập đủ điều kiện, không dùng cluster để chọn.',
              '- VNINDEX: benchmark chính thức, không phải strategy thứ sáu.', '',
              '## 6. Sáu tiêu chí và xếp hạng', '',
              '| Nhóm | Tiêu chí | Chiều tốt hơn |', '|---|---|---|']
    for block, key in [('Market', 'market_criteria'), ('Financial', 'financial_criteria')]:
        for criterion, higher in cfg[key].items():
            lines.append(f'| {block} | `{criterion}` | {"Cao hơn" if higher else "Thấp hơn"} |')
    lines += ['', 'Mỗi tiêu chí được chuyển sang average-rank percentile trong tập chấm điểm cùng kỳ. '
              'S_market và S_fin là trung bình các percentile của từng nhóm. '
              f'Điểm Combined = {cfg["combined_weight_market"]} × S_market + '
              f'{1 - cfg["combined_weight_market"]} × S_fin. '
              'Tie-break: điểm giảm dần, liquidity_21 giảm dần, ticker tăng dần. '
              f'Chọn ceil({cfg["top_share"]} × N_candidates); trọng số mục tiêu bằng nhau. '
              f'Với strategy áp dụng N_min={cfg["n_min"]}, kỳ không đủ ứng viên không tạo mua mới: '
              'giữ tỷ trọng mã cũ còn hợp lệ, bán mã đã ra khỏi tập ứng viên theo Q6.', '',
              '## 7. Giao dịch, tiền mặt và bốn bước', '',
              'Bước 1 tạo target tại decision date. Bước 2 revalue và giao dịch tại phiên tiếp theo: SELL trước BUY; '
              'volume 0 hoặc thiếu giá chặn giao dịch, chạm trần chặn BUY, chạm sàn chặn SELL, thiếu giới hạn giá '
              'fail-closed. SELL_FAILED giữ vị thế, BUY_FAILED giữ tiền; thiếu tiền thì giảm đồng tỷ lệ các lệnh '
              'mua còn thực hiện được. Bước 3 giữ và định giá đến execution kế tiếp hoặc end_date. '
              'Bước 4 chuyển trạng thái danh mục, không thực hiện thêm một lần giao dịch.', '',
              'Engine hoạt động trong value space, vốn ban đầu = 1, vị thế cho phép phân số và không làm tròn lô. '
              '`cash`, `nav`, `intended`, `executed` là giá trị vốn chuẩn hóa; `weight` là tỷ trọng. '
              'Cash ratio = cash/NAV. Turnover = tổng executed hai chiều/(2 × pre_trade_NAV). '
              'Missing price giữ last valid mark và ghi PRICE_STALE. Q17 chỉ sửa giá runtime khi đủ ba phiên '
              'exchange liền kề trong segment; raw input giữ nguyên. Cash sinh lãi 0; cost/slippage baseline = 0.', '',
              '## 8. Kết quả lịch sử đã đối chiếu', '',
              'Hai đoạn khởi tạo độc lập từ 100% CASH. Tổng lợi suất không so trực tiếp giữa các đoạn dài khác nhau; '
              'CAGR dùng số khoảng lợi suất/12 năm. Biến động năm dùng độ lệch chuẩn mẫu lợi suất theo kỳ × √12. '
              'Max drawdown chỉ đo tại ngày NAV được lưu, không phải daily drawdown. Không tính Sharpe cho Dev/Holdout.', '']
    for segment in ctx.runs:
        info = ctx.runs[segment]; manifest = info['manifest']
        rows = ctx.metrics_table(segment)
        lines += [f'### {segment.title()}', '',
                  f'Decision window `{manifest["segment_start"]}` → `{manifest["segment_end_date"]}`; '
                  f'{periods[segment]} decisions, {counts[segment]["executed"]} executions, '
                  f'{counts[segment]["not_executed_segment_end"]} kỳ cuối không execution. '
                  f'Có {info["metrics"]["combined"]["periods"]} khoảng lợi suất.', '',
                  '| Strategy/benchmark | Tổng lợi suất | CAGR | Biến động năm | Max drawdown | Turnover TB | Cash TB | Kỳ dưới N_min |',
                  '|---|---:|---:|---:|---:|---:|---:|---:|']
        for row in rows:
            values = [pct(row[key]) for key in ['total_return', 'cagr', 'volatility_annual', 'max_drawdown', 'avg_turnover', 'avg_cash_after_trading']]
            lines.append('| ' + row['strategy'] + ' | ' + ' | '.join(values) + f' | {row["too_small"] if row["too_small"] is not None else "—"} |')
        lines += ['', f'![Combined và VNINDEX — {segment}](figures/{segment}_nav_drawdown.png)', '',
                  f'![Combined với từng đối chứng — {segment}](figures/{segment}_controls_nav_drawdown.png)', '',
                  '| Strategy | BUY_FAILED | SELL_FAILED | SCALED | PRICE_STALE | LIMIT_DATA_MISSING |',
                  '|---|---:|---:|---:|---:|---:|']
        for name in cfg['strategies']:
            m = info['metrics'][name]
            lines.append('| ' + NAMES[name] + ' | ' + ' | '.join(str(m[k]) for k in ['failed_buys', 'failed_sells', 'scaled_buys', 'price_stale', 'limit_data_missing']) + ' |')
        lines += ['', 'Các số failed/scaled/stale là số sự kiện, không phải số mã duy nhất.', '']
    lines += ['## 9. Phân tích kết quả đối sánh', '',
              f'**Qua hai đoạn:** CAGR Combined tăng từ {pct(dc["cagr"])} lên {pct(hc["cagr"])}. '
              'Thứ hạng lợi suất trong năm strategy tăng từ thứ '
              f'{1 + sum(dev[n]["cagr"] > dc["cagr"] for n in cfg["strategies"])} lên thứ '
              f'{1 + sum(hold[n]["cagr"] > hc["cagr"] for n in cfg["strategies"])}. '
              'Thứ hạng còn phụ thuộc kết quả các đối chứng và giai đoạn thị trường, nên chưa chứng minh khả năng '
              'khái quát tốt hơn. Hai đoạn không phải kiểm định thống kê về hiệu quả tương lai.', '',
              f'**Market-only:** trong Dev, Combined có CAGR thấp hơn {pp(dc["cagr"] - dev["market_only"]["cagr"])} '
              'điểm phần trăm nhưng biến động và drawdown thuận lợi hơn. Trong Holdout, CAGR cao hơn '
              f'{pp(hc["cagr"] - hold["market_only"]["cagr"])} điểm phần trăm, đổi lại biến động cao hơn '
              f'{pp(hc["volatility_annual"] - hold["market_only"]["volatility_annual"])} điểm phần trăm và drawdown sâu hơn '
              f'{pp(hc["max_drawdown"] - hold["market_only"]["max_drawdown"])} điểm phần trăm. '
              'Lợi thế kết hợp chưa nhất quán trên cả lợi suất và rủi ro; chưa tách được đóng góp nhân quả của Financial.', '',
              '**Financial-only:** Combined có CAGR cao hơn trong cả hai đoạn, nhưng cũng biến động và sụt giảm '
              'lớn hơn. Trong Holdout, phần CAGR tăng thêm '
              f'{pp(hc["cagr"] - hold["financial_only"]["cagr"])} điểm phần trăm đi cùng biến động '
              f'{pct(hc["volatility_annual"])} so với {pct(hold["financial_only"]["volatility_annual"])}. '
              'Đây là đánh đổi giữa lợi suất và rủi ro, chưa phải ưu thế đồng thời.', '',
              '**Equal-weight:** trong Dev, đối chứng chia đều có CAGR cao hơn, biến động thấp hơn và drawdown '
              'ít sâu hơn Combined. Sang Holdout, Combined có CAGR cao hơn '
              f'{pp(hc["cagr"] - hold["equal_weight"]["cagr"])} điểm phần trăm, nhưng drawdown sâu hơn '
              f'{pp(hc["max_drawdown"] - hold["equal_weight"]["max_drawdown"])} điểm phần trăm. '
              'Quy trình chọn lọc chưa thể hiện lợi ích xuyên suốt hai đoạn; chưa phân rã nguồn rủi ro tăng.', '',
              '**Momentum-only:** có CAGR cao hơn, biến động thấp hơn và drawdown ít sâu hơn Combined trong cả '
              'Dev lẫn Holdout. Khoảng cách CAGR trong Holdout còn '
              f'{pp(hc["cagr"] - hold["momentum_only"]["cagr"])} điểm phần trăm, nhưng biến động Combined vẫn cao hơn '
              f'{pp(hc["volatility_annual"] - hold["momentum_only"]["volatility_annual"])} điểm phần trăm. '
              'Đây là đối chứng bất lợi rõ nhất cho giả thuyết phương án kết hợp phức tạp tạo thêm hiệu quả. '
              'Nhận định này mô tả ba chỉ tiêu, chưa xét ý nghĩa thống kê hoặc hiệu quả sau phí.', '',
              '**VNINDEX:** Combined cao hơn về lợi suất trong Dev, thấp hơn trong Holdout và drawdown sâu hơn '
              'trong cả hai đoạn. Vì khác return basis, không diễn giải phần chênh lệch thành alpha đã được xác nhận.', '',
              '**Điều kiện vận hành:** Combined có '
              f'{counts["development"]["too_small"]}/{periods["development"]} quyết định dưới N_min trong Dev và '
              f'{counts["holdout"]["too_small"]}/{periods["holdout"]} trong Holdout. Cash TB giảm từ '
              f'{pct(dc["avg_cash_after_trading"])} xuống {pct(hc["avg_cash_after_trading"])}; turnover TB tăng từ '
              f'{pct(dc["avg_turnover"])} lên {pct(hc["avg_turnover"])}. '
              'Đây là bối cảnh thay đổi mức vốn tham gia thị trường và giao dịch, chưa phải phân tích nguyên nhân '
              'của chênh lệch lợi suất. Turnover khác nhau khiến thứ hạng sau chi phí vẫn chưa được xác định.', '',
              '## 10. Giới hạn dữ liệu và phương pháp', '',
              '- Strategy dùng vendor-adjusted close như adjusted-return proxy; VNINDEX là price index. '
              'Khác biệt cơ sở giá ảnh hưởng cả lợi suất và drawdown. Chưa tách đóng góp cổ tức để định lượng chênh lệch.',
              '- Secondary price-only chưa sẵn sàng. Không thay raw_close trực tiếp vì sự kiện vốn có thể gây biến động '
              'giá cơ học. Chưa tái lập đầy đủ một total-return benchmark tương đồng.',
              '- Drawdown đo theo kỳ; missing price có dùng last valid mark. Không mặc định thiếu dữ liệu bằng zero.',
              '- Chi phí/slippage 0, vị thế phân số, không có sổ lệnh hoặc ràng buộc sức chứa dựa trên quy mô vốn thực. '
              'Volume/trần/sàn chỉ là rule executable đã khóa.',
              '- Financial vintage/revision và các phát hiện VCG/SBT được owner chấp nhận như giới hạn snapshot; '
              'PIT ngày/cutoff không xác nhận số tài chính là vintage nguyên thủy. Xem '
              '[disclosure nguồn](../../docs/REPORT_BACKTEST.md#32-q-date-và-các-điểm-cần-xác-minh-về-dữ-liệu-tài-chính).',
              '- Độ ổn định B v4 chưa đạt ngưỡng mong muốn là giới hạn upstream; notebook không lựa chọn lại model '
              'bằng kết quả danh mục. Holdout sạch ở tầng portfolio-rule/return-based evaluation, không khẳng định '
              'hoàn toàn unseen đối với mọi lịch sử lựa chọn mô hình upstream.', '',
              '## 11. Final Evaluation và trạng thái M3-C', '',
              '**Final = NOT_READY:** owner xác nhận chưa đủ dữ liệu 2026; chưa có segment/window Final và run Final '
              'đã seal. Notebook 04 ghi trạng thái chờ, không tạo số liệu hoặc dùng Holdout thay Final. '
              'M3-C phần Dev/Holdout có bằng chứng tái lập; tổng thể vẫn PARTIAL cho đến khi đánh giá Final hoàn tất.', '',
              '## 12. Hướng dẫn tái lập và ranh giới dashboard', '',
              'Xem [hướng dẫn thực thi](../HUONG_DAN_THUC_HIEN_M3.md) và bộ notebook ở `M3/notebooks/`. '
              'Mỗi lần thực thi lưu preflight, đối chiếu ba notebook, hash notebook/report/biểu đồ và môi trường '
              'trong thư mục reproduction riêng. Không cần chạy lại acquisition hoặc build B-PIT.', '',
              'M3-B là lớp dashboard đọc versioned/sealed artifacts; phần này không xây gói dashboard hoặc kiểm thử '
              'API/frontend thay M3-B. Báo cáo chưa có bằng chứng nghiệm thu dashboard mới.', '',
              '## 13. Kết luận trong phạm vi lịch sử', '',
              'Combined cải thiện thứ hạng ở Holdout nhưng chưa có ưu thế nhất quán đồng thời về lợi suất và rủi ro. '
              'Momentum-only thuận lợi hơn trên CAGR, volatility và drawdown ở cả hai đoạn. '
              'Verify/reproduction PASS xác nhận tuân thủ contract và khả năng tái lập, không chứng minh hiệu quả '
              'đầu tư vượt trội hoặc chất lượng phân cụm tốt hơn. Quy tắc frozen được giữ nguyên sau đánh giá.', '']
    return '\n'.join(lines)
